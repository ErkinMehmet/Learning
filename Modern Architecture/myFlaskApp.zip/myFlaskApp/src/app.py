#!/usr/bin/env python3
from flask import Flask, request,jsonify
import requests
from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'  # Relative path to SQLite database
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

API_KEY="3f06d4fe5d444f10b8821016241211"


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name=db.Column(db.String(50), nullable=False)
    title=db.Column(db.String(50), nullable=True)

class Weather(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    temp_c=db.Column(db.String(50), nullable=False)

@app.before_request
def init_db():
    db.create_all()



@app.route("/")
def main():
    return '''
        <form action="/getData" method="POST">
            <input type="text" name="city" value="Montreal">
            <button type="submit">Get Data!</button>
        </form>
    '''
"""
@app.route("/echo",methods=['POST'])
def echo():
    input=request.form['user_input']
    return f'''
        Did you type {input}?
    '''
"""
@app.route("/getData",methods=['POST'])
def get_users():
    city=request.form['city']
    url="http://api.weatherapi.com/v1/current.json?key="+API_KEY+"&q="+city
    print(url,city)
    res = requests.get(url)
    if res.status_code != 200:
        return jsonify({"error": "City invalid"}), 404
    dat = res.json()
    print(str(dat))
    new_weather={dat['current']['temp_c']} #lazy lets just do temp
    return f'''<p>This is the current weather for {city}: {new_weather} C</p>
         <form method="POST" action="/"><button type="submit">GoBack</button></form>
    '''

    """
    myJson=User(
    name="Rodriguez",
    title ="Business Analyst"
    )
    db.session.add(myJson)
    db.session.commit()
    users=User.query.all()
    if not users:
        return jsonify({"message":"no user found"}),404

    for user in users:
        print(user.id,user.name,user.title)
    return f'''
        {users[0].name} leng: {len(users)}
    '''
    """

if __name__ == "__main__":
    app.run(debug=True)
